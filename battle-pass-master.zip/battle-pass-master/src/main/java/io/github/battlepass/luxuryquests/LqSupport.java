package io.github.battlepass.luxuryquests;

public class LqSupport {
}
