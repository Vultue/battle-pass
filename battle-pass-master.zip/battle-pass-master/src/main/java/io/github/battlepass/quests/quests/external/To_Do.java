package io.github.battlepass.quests.quests.external;

public class To_Do {
    /*
     Yes, this is a to-do list in a Java class :).

     Plugins to add support for:

       AuctionHouse by Kludge - DONE
       ASkyblock - DONE
     BentoBox - CAN'T DO, TRASH API
       Bedwars1058 - DONE
       ChestShop - DONE
     CrazyAuctions
       CrazyEnvoy - DONE
     GadgetsMenu
     MarriageMaster
       ProCosmetics - WAITING ON API but nearly done ;)
     ProPractice
     ScreamingBedWars
     SkyWars by Daboross
       StrikePractice - DONE
       SuperiorSkyblock - DONE
       TokenEnchant - DONE
     AutoSell
     BossShopPro
     BossTM
       ChatReaction - DONE
       Citizens - DONE
       CrateReloaded - DONE
       CrazyCrates - DONE
       CratesPlus - DONE
       DiscordMinecraft - DONE
     HungerGames by ShaneBee
     MythicMobs
       PlotSquared - DONE
       uSkyBlock - DONE
       Jobs https://www.spigotmc.org/resources/jobs-reborn.4216/ - DONE
       MoneyHunters https://www.spigotmc.org/resources/moneyhunters-1-13-1-15.22450/ - DONE
       Clans https://www.spigotmc.org/resources/clans-clan-system-1-7-1-15.22304/ - DONE
     DisplayShops

     */
}
