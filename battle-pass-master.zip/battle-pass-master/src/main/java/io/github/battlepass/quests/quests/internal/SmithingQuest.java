package io.github.battlepass.quests.quests.internal;

import io.github.battlepass.BattlePlugin;
import io.github.battlepass.quests.QuestExecutor;

public class SmithingQuest extends QuestExecutor {

    public SmithingQuest(BattlePlugin plugin) {
        super(plugin);
    }
}
