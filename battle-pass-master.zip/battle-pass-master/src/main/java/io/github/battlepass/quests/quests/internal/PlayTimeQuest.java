package io.github.battlepass.quests.quests.internal;

import io.github.battlepass.BattlePlugin;
import io.github.battlepass.quests.QuestExecutor;

public class PlayTimeQuest extends QuestExecutor {

    public PlayTimeQuest(BattlePlugin plugin) {
        super(plugin);
    }
}
