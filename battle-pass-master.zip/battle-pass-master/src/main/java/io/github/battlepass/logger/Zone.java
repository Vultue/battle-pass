package io.github.battlepass.logger;

public enum Zone {

    GENERAL,
    RELOAD,
    START,
}
